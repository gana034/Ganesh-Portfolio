# Ganesh-Portfolio
This is my personal portfolio built with HTML and CSS. Includes my projects, internships, and resume.
